/*
 * PersonView.java
 */

package person;

import com.ruimo.gui.ModelLifeCycleManager;
import com.ruimo.gui.SimpleModelLifeCycleContext;
import java.awt.Component;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.EventObject;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.application.Application;
import org.jdesktop.application.Application.ExitListener;
import org.jdesktop.beansbinding.Binding;
import org.jdesktop.beansbinding.Binding.SyncFailure;
import org.jdesktop.beansbinding.Binding.SyncFailureType;
import org.jdesktop.beansbinding.BindingListener;
import org.jdesktop.beansbinding.PropertyStateEvent;

/**
 * The application's main frame.
 */
public class PersonView extends FrameView {

    public PersonView(SingleFrameApplication app) {
        super(app);

        modelLifeCycleManager = new ModelLifeCycleManager<Person>();
        ResourceMap resourceMap = getResourceMap();
        JFileChooser saveFileChooser = new JFileChooser();
        saveFileChooser.setMultiSelectionEnabled(false);

        JFileChooser openFileChooser = new JFileChooser();
        openFileChooser.setMultiSelectionEnabled(false);

        PersonModelLifeCycleContext context = new PersonModelLifeCycleContext
            (getFrame(), resourceMap.getString("save.query.title"),
             resourceMap.getString("save.query.message"),
             resourceMap.getIcon("save.query.icon"),
             resourceMap.getString("query.overwrite.title"),
             resourceMap.getString("query.overwrite.message"),
             resourceMap.getIcon("query.overwrite.icon"),
             resourceMap.getString("fix.error"),
             resourceMap.getString("fix.error"),
             resourceMap.getIcon("fix.error.icon"),
             resourceMap.getString("file.save.error"),
             resourceMap.getString("file.save.error"),
             resourceMap.getIcon("file.save.error.icon"),
             resourceMap.getString("file.open.error"),
             resourceMap.getString("file.open.error"),
             resourceMap.getIcon("file.open.error.icon"),
             saveFileChooser, openFileChooser);
        modelLifeCycleManager.start(Person.class, context);

        initComponents();

        getApplication().addExitListener(new ExitListener() {
            public boolean canExit(EventObject event) {
                return modelLifeCycleManager.invokeCloseModel(bindingGroup);
            }

            public void willExit(EventObject event) {}
        });

        bindingGroup.addBindingListener(new BindingChecker());
        // status bar initialization - message timeout, idle icon and busy animation, etc
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String)(evt.getNewValue());
                    statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer)(evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = getFrame();
            aboutBox = new PersonAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        PersonApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        mainPanel = new javax.swing.JPanel();
        nameLabel = new javax.swing.JLabel();
        nameTextField = new javax.swing.JTextField();
        ageLabel = new javax.swing.JLabel();
        ageTextField = new javax.swing.JTextField();
        nameErrorLabel = new javax.swing.JLabel();
        ageErrorLabel = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        newMenuItem = new javax.swing.JMenuItem();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        saveAsMenuItem = new javax.swing.JMenuItem();
        closeMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoMenuItem = new javax.swing.JMenuItem();
        redoMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        nameValidator = new person.RequiredValidator();
        ageValidator = new person.MinMaxValidator<Integer>();
        modelLifeCycleManager = modelLifeCycleManager;
        jToolBar1 = new javax.swing.JToolBar();
        newPersonButton = new javax.swing.JButton();
        openPersonButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        saveAsButton = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        undoButton = new javax.swing.JButton();
        redoButton = new javax.swing.JButton();

        mainPanel.setName("mainPanel"); // NOI18N

        nameLabel.setDisplayedMnemonic('N');
        nameLabel.setLabelFor(nameTextField);
        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(person.PersonApp.class).getContext().getResourceMap(PersonView.class);
        nameLabel.setText(resourceMap.getString("nameLabel.text")); // NOI18N
        nameLabel.setName("nameLabel"); // NOI18N

        nameTextField.setName("nameTextField"); // NOI18N

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${model.name}"), nameTextField, org.jdesktop.beansbinding.BeanProperty.create("text"), "person.name");
        binding.setValidator(nameValidator);
        bindingGroup.addBinding(binding);

        ageLabel.setDisplayedMnemonic('A');
        ageLabel.setLabelFor(ageTextField);
        ageLabel.setText(resourceMap.getString("ageLabel.text")); // NOI18N
        ageLabel.setName("ageLabel"); // NOI18N

        ageTextField.setName("ageTextField"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${model.age}"), ageTextField, org.jdesktop.beansbinding.BeanProperty.create("text"), "person.age");
        binding.setValidator(ageValidator);
        bindingGroup.addBinding(binding);

        nameErrorLabel.setFont(resourceMap.getFont("ageErrorLabel.font")); // NOI18N
        nameErrorLabel.setForeground(resourceMap.getColor("ageErrorLabel.foreground")); // NOI18N
        nameErrorLabel.setText(resourceMap.getString("nameErrorLabel.text")); // NOI18N
        nameErrorLabel.setName("nameErrorLabel"); // NOI18N

        ageErrorLabel.setFont(resourceMap.getFont("ageErrorLabel.font")); // NOI18N
        ageErrorLabel.setForeground(resourceMap.getColor("ageErrorLabel.foreground")); // NOI18N
        ageErrorLabel.setText(resourceMap.getString("ageErrorLabel.text")); // NOI18N
        ageErrorLabel.setName("ageErrorLabel"); // NOI18N

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nameLabel)
                    .addComponent(ageLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ageTextField)
                    .addComponent(nameTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ageErrorLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                    .addComponent(nameErrorLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameLabel)
                    .addComponent(nameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nameErrorLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ageLabel)
                    .addComponent(ageTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ageErrorLabel))
                .addContainerGap(148, Short.MAX_VALUE))
        );

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        newMenuItem.setMnemonic('N');
        newMenuItem.setText(resourceMap.getString("newMenuItem.text")); // NOI18N
        newMenuItem.setName("newMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${newModelMenuEnabled}"), newMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        newMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(newMenuItem);

        openMenuItem.setMnemonic('O');
        openMenuItem.setText(resourceMap.getString("openMenuItem.text")); // NOI18N
        openMenuItem.setName("openMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${openModelMenuEnabled}"), openMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        openMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(openMenuItem);

        saveMenuItem.setMnemonic('S');
        saveMenuItem.setText(resourceMap.getString("saveMenuItem.text")); // NOI18N
        saveMenuItem.setName("saveMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${saveModelMenuEnabled}"), saveMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveMenuItem);

        saveAsMenuItem.setMnemonic('A');
        saveAsMenuItem.setText(resourceMap.getString("saveAsMenuItem.text")); // NOI18N
        saveAsMenuItem.setName("saveAsMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${saveModelAsMenuEnabled}"), saveAsMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveAsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveAsMenuItem);

        closeMenuItem.setMnemonic('C');
        closeMenuItem.setText(resourceMap.getString("closeMenuItem.text")); // NOI18N
        closeMenuItem.setName("closeMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${closeModelMenuEnabled}"), closeMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        closeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(closeMenuItem);

        jSeparator1.setName("jSeparator1"); // NOI18N
        fileMenu.add(jSeparator1);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(person.PersonApp.class).getContext().getActionMap(PersonView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setMnemonic('X');
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        editMenu.setMnemonic('E');
        editMenu.setText(resourceMap.getString("editMenu.text")); // NOI18N
        editMenu.setName("editMenu"); // NOI18N

        undoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        undoMenuItem.setMnemonic('U');
        undoMenuItem.setName("undoMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${undoPossible}"), undoMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${undoPresentationName}"), undoMenuItem, org.jdesktop.beansbinding.BeanProperty.create("text"));
        bindingGroup.addBinding(binding);

        undoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(undoMenuItem);

        redoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        redoMenuItem.setMnemonic('R');
        redoMenuItem.setName("redoMenuItem"); // NOI18N

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${redoPossible}"), redoMenuItem, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${redoPresentationName}"), redoMenuItem, org.jdesktop.beansbinding.BeanProperty.create("text"));
        bindingGroup.addBinding(binding);

        redoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(redoMenuItem);

        menuBar.add(editMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 214, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusMessageLabel)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        ageValidator.setMax(300);
        ageValidator.setMin(0);

        jToolBar1.setRollover(true);
        jToolBar1.setName("jToolBar1"); // NOI18N

        newPersonButton.setIcon(resourceMap.getIcon("newPersonButton.icon")); // NOI18N
        newPersonButton.setText(resourceMap.getString("newPersonButton.text")); // NOI18N
        newPersonButton.setFocusable(false);
        newPersonButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newPersonButton.setName("newPersonButton"); // NOI18N
        newPersonButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${newModelMenuEnabled}"), newPersonButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        newPersonButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newPersonButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(newPersonButton);

        openPersonButton.setIcon(resourceMap.getIcon("openPersonButton.icon")); // NOI18N
        openPersonButton.setText(resourceMap.getString("openPersonButton.text")); // NOI18N
        openPersonButton.setFocusable(false);
        openPersonButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openPersonButton.setName("openPersonButton"); // NOI18N
        openPersonButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${openModelMenuEnabled}"), openPersonButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        openPersonButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openPersonButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(openPersonButton);

        saveButton.setIcon(resourceMap.getIcon("saveButton.icon")); // NOI18N
        saveButton.setText(resourceMap.getString("saveButton.text")); // NOI18N
        saveButton.setFocusable(false);
        saveButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveButton.setName("saveButton"); // NOI18N
        saveButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${saveModelMenuEnabled}"), saveButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(saveButton);

        saveAsButton.setIcon(resourceMap.getIcon("saveAsButton.icon")); // NOI18N
        saveAsButton.setText(resourceMap.getString("saveAsButton.text")); // NOI18N
        saveAsButton.setFocusable(false);
        saveAsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveAsButton.setName("saveAsButton"); // NOI18N
        saveAsButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${saveModelAsMenuEnabled}"), saveAsButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveAsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(saveAsButton);

        jSeparator2.setName("jSeparator2"); // NOI18N
        jToolBar1.add(jSeparator2);

        undoButton.setIcon(resourceMap.getIcon("undoButton.icon")); // NOI18N
        undoButton.setText(resourceMap.getString("undoButton.text")); // NOI18N
        undoButton.setFocusable(false);
        undoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        undoButton.setName("undoButton"); // NOI18N
        undoButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${undoPossible}"), undoButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        undoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(undoButton);

        redoButton.setIcon(resourceMap.getIcon("redoButton.icon")); // NOI18N
        redoButton.setText(resourceMap.getString("redoButton.text")); // NOI18N
        redoButton.setFocusable(false);
        redoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        redoButton.setName("redoButton"); // NOI18N
        redoButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, modelLifeCycleManager, org.jdesktop.beansbinding.ELProperty.create("${redoPossible}"), redoButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        redoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(redoButton);

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
        setToolBar(jToolBar1);

        bindingGroup.bind();
    }// </editor-fold>//GEN-END:initComponents

private void newMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newMenuItemActionPerformed
    modelLifeCycleManager.invokeNewModel(bindingGroup);
}//GEN-LAST:event_newMenuItemActionPerformed

private void openMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMenuItemActionPerformed
    modelLifeCycleManager.invokeOpenModel(bindingGroup);
}//GEN-LAST:event_openMenuItemActionPerformed

private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMenuItemActionPerformed
    modelLifeCycleManager.invokeSaveModel(bindingGroup);
}//GEN-LAST:event_saveMenuItemActionPerformed

private void saveAsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsMenuItemActionPerformed
    modelLifeCycleManager.invokeSaveAsModel(bindingGroup);
}//GEN-LAST:event_saveAsMenuItemActionPerformed

private void closeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeMenuItemActionPerformed
    modelLifeCycleManager.invokeCloseModel(bindingGroup);
}//GEN-LAST:event_closeMenuItemActionPerformed

private void undoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoMenuItemActionPerformed
    modelLifeCycleManager.undo();
}//GEN-LAST:event_undoMenuItemActionPerformed

private void redoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoMenuItemActionPerformed
    modelLifeCycleManager.redo();
}//GEN-LAST:event_redoMenuItemActionPerformed

private void newPersonButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newPersonButtonActionPerformed
    modelLifeCycleManager.invokeNewModel(bindingGroup);
}//GEN-LAST:event_newPersonButtonActionPerformed

private void openPersonButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openPersonButtonActionPerformed
    modelLifeCycleManager.invokeOpenModel(bindingGroup);
}//GEN-LAST:event_openPersonButtonActionPerformed

private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
    modelLifeCycleManager.invokeSaveModel(bindingGroup);
}//GEN-LAST:event_saveButtonActionPerformed

private void saveAsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsButtonActionPerformed
    modelLifeCycleManager.invokeSaveAsModel(bindingGroup);
}//GEN-LAST:event_saveAsButtonActionPerformed

private void undoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoButtonActionPerformed
    modelLifeCycleManager.undo();
}//GEN-LAST:event_undoButtonActionPerformed

private void redoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoButtonActionPerformed
    modelLifeCycleManager.redo();
}//GEN-LAST:event_redoButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ageErrorLabel;
    private javax.swing.JLabel ageLabel;
    private javax.swing.JTextField ageTextField;
    private person.MinMaxValidator<Integer> ageValidator;
    private javax.swing.JMenuItem closeMenuItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private com.ruimo.gui.ModelLifeCycleManager<Person> modelLifeCycleManager;
    private javax.swing.JLabel nameErrorLabel;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JTextField nameTextField;
    private person.RequiredValidator nameValidator;
    private javax.swing.JMenuItem newMenuItem;
    private javax.swing.JButton newPersonButton;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JButton openPersonButton;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JButton redoButton;
    private javax.swing.JMenuItem redoMenuItem;
    private javax.swing.JButton saveAsButton;
    private javax.swing.JMenuItem saveAsMenuItem;
    private javax.swing.JButton saveButton;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JButton undoButton;
    private javax.swing.JMenuItem undoMenuItem;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;

    private JDialog aboutBox;

    class BindingChecker implements BindingListener {
        public void bindingBecameBound(Binding binding) {}
        public void bindingBecameUnbound(Binding binding) {}

        public void syncFailed(Binding binding, SyncFailure failure) {
            ResourceMap resourceMap = Application.getInstance
                (PersonApp.class).getContext().getResourceMap(PersonView.class);
            if ("person.name".equals(binding.getName())) {
                if (failure.getType() == SyncFailureType.VALIDATION_FAILED) {
                    nameErrorLabel.setText(resourceMap.getString("input.required.error"));
                }
            }
            else if ("person.age".equals(binding.getName())) {
                if (failure.getType() == SyncFailureType.CONVERSION_FAILED) {
                    ageErrorLabel.setText(resourceMap.getString("number.format.error"));
                }
                else if (failure.getType() == SyncFailureType.VALIDATION_FAILED) {
                    if (failure.getValidationResult().getErrorCode() ==
                        MinMaxValidator.ErrorCode.BELOW_MIN)
                    {
                        ageErrorLabel.setText
                            (String.format(resourceMap.getString("min.value.error"),
                                           ageValidator.getMin(),
                                           ageValidator.getMax()));
                    }
                    else if (failure.getValidationResult().getErrorCode() ==
                             MinMaxValidator.ErrorCode.ABOVE_MAX)
                    {
                        ageErrorLabel.setText
                            (String.format(resourceMap.getString("max.value.error"),
                                           ageValidator.getMin(),
                                           ageValidator.getMax()));
                    }
                    else {
                        ageErrorLabel.setText(resourceMap.getString("invalid.value.error"));
                    }
                }
            }
        }

        public void synced(Binding binding) {
            if ("person.name".equals(binding.getName())) {
                nameErrorLabel.setText("");
            }
            else if ("person.age".equals(binding.getName())) {
                ageErrorLabel.setText("");
            }
        }

        public void sourceChanged(Binding binding, PropertyStateEvent event) {}
        public void targetChanged(Binding binding, PropertyStateEvent event) {}
    }

    void fileError(File file, String messageKey, Throwable cause) {
        JFrame parent = getFrame();
        ResourceMap resourceMap = Application.getInstance
            (PersonApp.class).getContext().getResourceMap(PersonView.class);

        JOptionPane.showMessageDialog
            (parent,
             String.format(resourceMap.getString(messageKey),
                           file.getAbsolutePath()));
        Logger.getLogger(PersonView.class.getName()).log(Level.SEVERE, null, cause);
    }

    class PersonModelLifeCycleContext extends SimpleModelLifeCycleContext<Person> {
        PersonModelLifeCycleContext
            (Component parent,
             String saveQueryTitle, String saveQueryMessage, Icon saveQueryIcon,
             String queryOverwriteTitle, String queryOverwriteMessage, Icon queryOverwriteIcon,
             String fixErrorTitle, String fixErrorMessage, Icon fixErrorIcon,
             String fileSaveErrorTitle, String fileSaveErrorMessage, Icon fileSaveErrorIcon,
             String fileOpenErrorTitle, String fileOpenErrorMessage, Icon fileOpenErrorIcon,
             JFileChooser querySaveFileChooser,
             JFileChooser queryOpenFileChooser)
        {
            super (parent, saveQueryTitle, saveQueryMessage, saveQueryIcon,
                   queryOverwriteTitle, queryOverwriteMessage, queryOverwriteIcon,
                   fixErrorTitle, fixErrorMessage, fixErrorIcon,
                   fileSaveErrorTitle, fileSaveErrorMessage, fileSaveErrorIcon,
                   fileOpenErrorTitle, fileOpenErrorMessage, fileOpenErrorIcon,
                   querySaveFileChooser, queryOpenFileChooser);
        }

        @Override public void setInitialValue(Person person) {
            ResourceMap resourceMap = Application.getInstance
                (PersonApp.class).getContext().getResourceMap(PersonView.class);
            person.setName(resourceMap.getString("name.default"));
            person.setAge(resourceMap.getInteger("age.default"));
        }
    }
}
