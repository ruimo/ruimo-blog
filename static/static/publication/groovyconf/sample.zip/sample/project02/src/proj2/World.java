package proj2;

public class World {
}
