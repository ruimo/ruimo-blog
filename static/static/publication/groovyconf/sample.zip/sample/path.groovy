LIB_DIR = BASE_DIR + 'lib'
CLASS_DIR = BASE_DIR + 'classes'
SRC_DIR = BASE_DIR + 'src'
