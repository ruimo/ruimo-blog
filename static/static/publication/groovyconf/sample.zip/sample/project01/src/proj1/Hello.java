package proj1;

public class Hello {
}
