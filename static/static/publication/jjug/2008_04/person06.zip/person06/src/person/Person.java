package person;

import java.io.Serializable;

public class Person implements Serializable {
    private static final long serialVersionUID = 6522075927845542296L;

    String name;
    int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null) name = "";
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
