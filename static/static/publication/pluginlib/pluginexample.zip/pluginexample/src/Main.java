import java.io.File;
import java.io.IOException;

import com.ruimo.pluginlib.PluginRepository;

public class Main {
    public static void main(String[] args) throws IOException {
        PluginRepository<HelloPlugin>pluginRepository
            = new PluginRepository<HelloPlugin>(new File("plugins"));

        for (HelloPlugin plugin:pluginRepository.plugins()) {
            plugin.hello(args[0]);
        }
    }
}
