import com.ruimo.pluginlib.Plugin;

public class MyPlugin implements HelloPlugin {
    final String greeting;

    public MyPlugin(String greeting) {
        if (greeting == null) throw new NullPointerException();
        this.greeting = greeting;
    }

    public void hello(String name) {
        System.out.printf(greeting, name);
    }

    public String getName() {
        return "Plugin example.";
    }
}
