import com.ruimo.pluginlib.Plugin;

public interface HelloPlugin extends Plugin {
    void hello(String name);
}
