package com.ruimo.pluginlib;

/**
 * Plugin interface.
 *
 * All plugins should implement this interface.
 * @author S.Hanai
 */
public interface Plugin {
    /**
     * Returns name of this plugin.
     * @return name of this plugin. Should not return null.
     */
    String getName();
}
