File.metaClass.plus = {String child -> new File(delegate, child)}
